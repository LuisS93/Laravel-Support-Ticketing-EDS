
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.customer.title')); ?>

    </div>

    <div class="card-body">
        <div class="mb-2">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->company_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.address')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->address); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.city')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->city); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.country')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->country); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.zip')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->zip); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.phone')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->phone); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->email); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.contactperson')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->contact_person); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.phonecontactperson')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->phone_contact_person); ?>

                        </td>   
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.contactpersonemail')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->email_contact_person); ?>

                        </td>   
                    </tr>
                    
                </tbody>
            </table>
            <a style="margin-top:20px;" class="btn btn-default" href="<?php echo e(url()->previous()); ?>">
                <?php echo e(trans('global.back_to_list')); ?>

            </a>
        </div>

        <nav class="mb-3">
            <div class="nav nav-tabs">

            </div>
        </nav>
        <div class="tab-content">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Laravel-Support-Ticketing-EDS\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>