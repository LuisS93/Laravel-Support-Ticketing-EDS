<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\Laravel-Support-Ticketing-EDS\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>