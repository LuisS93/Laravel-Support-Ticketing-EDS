
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.customer.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.customers.update", [$customer->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('company_name') ? 'has-error' : ''); ?>">
            <label for="company_name"><?php echo e(trans('cruds.customer.fields.name')); ?>*</label>
            <input type="text" id="company_name" name="company_name" class="form-control" value="<?php echo e(old('name', isset($customer) ? $customer->company_name : '')); ?>" required>
            <?php if($errors->has('company_name')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('company_name')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.name_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
            <label for="address"><?php echo e(trans('cruds.customer.fields.address')); ?></label>
            <input type="text" id="address" name="address" class="form-control" value="<?php echo e(old('address', isset($customer) ? $customer->address : '')); ?>">
            <?php if($errors->has('address')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('address')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.address_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('city') ? 'has-error' : ''); ?>">
            <label for="city"><?php echo e(trans('cruds.customer.fields.city')); ?></label>
            <input type="text" id="city" name="city" class="form-control" value="<?php echo e(old('city', isset($customer) ? $customer->city : '')); ?>">
            <?php if($errors->has('city')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('city')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.city_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('country') ? 'has-error' : ''); ?>">
            <label for="country"><?php echo e(trans('cruds.customer.fields.country')); ?></label>
            <input type="text" id="country" name="country" class="form-control" value="<?php echo e(old('country', isset($customer) ? $customer->country : '')); ?>">
            <?php if($errors->has('country')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('country')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.country_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('zip') ? 'has-error' : ''); ?>">
            <label for="zip"><?php echo e(trans('cruds.customer.fields.zip')); ?></label>
            <input type="text" id="zip" name="zip" class="form-control" value="<?php echo e(old('zip', isset($customer) ? $customer->zip : '')); ?>">
            <?php if($errors->has('zip')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('zip')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.zip_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
            <label for="phone"><?php echo e(trans('cruds.customer.fields.phone')); ?></label>
            <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('phone', isset($customer) ? $customer->phone : '')); ?>">
            <?php if($errors->has('phone')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('phone')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.phone_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
            <label for="email"><?php echo e(trans('cruds.customer.fields.email')); ?></label>
            <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email', isset($customer) ? $customer->email : '')); ?>">
            <?php if($errors->has('email')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('email')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.email_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('contact_person') ? 'has-error' : ''); ?>">
            <label for="contact_person"><?php echo e(trans('cruds.customer.fields.contactperson')); ?></label>
            <input type="text" id="contact_person" name="contact_person" class="form-control" value="<?php echo e(old('contact_person', isset($customer) ? $customer->contact_person : '')); ?>">
            <?php if($errors->has('contact_person')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('contact_person')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.contactperson_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('phone_contact_person') ? 'has-error' : ''); ?>">
            <label for="phone_contact_person"><?php echo e(trans('cruds.customer.fields.phonecontactperson')); ?></label>
            <input type="text" id="phone_contact_person" name="phone_contact_person" class="form-control" value="<?php echo e(old('phone_contact_person', isset($customer) ? $customer->phone_contact_person : '')); ?>">
            <?php if($errors->has('phone_contact_person')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('phone_contact_person')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.phonecontactperson_helper')); ?>

            </p>
        </div>

        <div class="form-group <?php echo e($errors->has('email_contact_person') ? 'has-error' : ''); ?>">
            <label for="email_contact_person"><?php echo e(trans('cruds.customer.fields.contactpersonemail')); ?></label>
            <input type="text" id="email_contact_person" name="email_contact_person" class="form-control" value="<?php echo e(old('email_contact_person', isset($customer) ? $customer->email_contact_person : '')); ?>">
            <?php if($errors->has('email_contact_person')): ?>
                <em class="invalid-feedback">
                    <?php echo e($errors->first('email_contact_person')); ?>

                </em>
            <?php endif; ?>
            <p class="helper-block">
                <?php echo e(trans('cruds.customer.fields.contactpersonemail_helper')); ?>

            </p>
        </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Laravel-Support-Ticketing-EDS\resources\views/admin/customers/edit.blade.php ENDPATH**/ ?>